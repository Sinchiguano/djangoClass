for item in range(0,10):
    print(item)


frameworks = [
    "Django",
    "Flask",
    "FastAPI",
    "Pyramid",
    "Tornado",
    "AIOHTTP",
    "Falcon",
    "Hug",
    "CherryPy",
    "Web2py"
]

print(frameworks)



for index, framework in enumerate(frameworks):
    print(f"In the {index}, it is {framework}")
